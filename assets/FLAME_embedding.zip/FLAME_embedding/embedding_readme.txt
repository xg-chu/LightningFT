FLAME_masks.pkl: https://files.is.tue.mpg.de/tbolkart/FLAME/FLAME_masks.zip
head_template_mesh.obj: https://keeper.mpdl.mpg.de/f/f158a430ef754edba5ec/?dl=1
landmark_embedding.npy: https://keeper.mpdl.mpg.de/f/f158a430ef754edba5ec/?dl=1
mediapipe_landmark_embedding.npz: https://files.is.tue.mpg.de/tbolkart/FLAME/mediapipe_landmark_embedding.zip